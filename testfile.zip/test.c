#include<stdio.h>
int getint() {
  int n ;
  scanf("%d",&n);
  return n;
}
const int N1n1 = 10000;
int N = 114514,NN=12121;
void useLess() {
  printf("UseLess");
  return;
}
int main() {
  printf("20373057\n");
  int a1a1 = 9;
  const int tmpC = 9527;
  {
    int a1a1 = 9;
    const int tmpC = 9526;
    printf("%d\n",tmpC);
    a1a1 = 44;
  }
  {}
  {;}
  a1a1=a1a1+1;
  int tmp,tmp1;
  printf("%d\n",(N+a1a1) * N1n1);
  useLess();
  return 0;
}
/*
anonymous text
*/