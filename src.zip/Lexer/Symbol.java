package Lexer;

public enum Symbol {

}
