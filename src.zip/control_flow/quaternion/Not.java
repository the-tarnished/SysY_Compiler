package control_flow.quaternion;

import node.Node;

public class Not extends Single{
    public Not(String arg1, String arg2) {
        super(arg1, arg2, QuaternionKind.Not);
    }

}
