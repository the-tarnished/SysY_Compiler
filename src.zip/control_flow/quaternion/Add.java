package control_flow.quaternion;

public class Add extends Binary{

    public Add(String arg1,String arg2,String arg3) {
        super(arg1,arg2,arg3,QuaternionKind.Add);
    }

}
