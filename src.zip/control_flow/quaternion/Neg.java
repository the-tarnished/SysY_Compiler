package control_flow.quaternion;

import node.Node;

public class Neg extends Single{
    public Neg(String arg1, String arg2) {
        super(arg1, arg2, QuaternionKind.Neg);
    }

}
