package node;

import error.ErrorRet;

public class AddExpNode extends Node{
    public AddExpNode(SyntaxKind input) {
        super(input);
    }

    @Override
    public void print() {
        printChildren();
        printSyntaxKind();
    }

    @Override
    public ErrorRet check() {
        ErrorRet ret = new ErrorRet();
        boolean flag = true;
        boolean canCal = false;
        String  op = "";
        if (getChildren().size() == 1) {
            ret = getChildren().get(0).check();
        } else {
            for (Node node:getChildren()) {
                ErrorRet tmp = node.check();
                ret.errorList.addAll(tmp.errorList);
                ret.dimension.addAll(tmp.dimension);
                if (flag) {
                    ret.value = tmp.value;
                    flag = false;
                }
                if (canCal) { // 一定可以计算出来
                    switch (op) {
                        case "+":
                            //ret.value.set(0,ret.value.get(0) +  tmp.value.get(0));
                            ret.value.set(0,1);
                            break;
                        case "-":
                            //ret.value.set(0,ret.value.get(0) -  tmp.value.get(0));
                            ret.value.set(0,1);
                            break;
                        default:
                            break;
                    }
                }
                if (node instanceof TerminalTkNode && symbol.isConst()) { // 一定可以计算出来
                    canCal =  true;
                    op = ((TerminalTkNode) node).getWord().getText();
                }
            }
        }
        return ret;
    }
}
