package Node;

public class UnaryOpNode extends Node{
    public UnaryOpNode(SyntaxKind input) {
        super(input);
    }

    @Override
    public void print() {
        printChildren();
        printSyntaxKind();
    }
}
