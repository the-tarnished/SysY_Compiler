package Node;

import Lexer.Token;

import java.util.ArrayList;

public abstract class Node {

    private ArrayList<Node> children;
    private SyntaxKind syntaxKind;

    public Node(SyntaxKind input) {
        children = new ArrayList<>();
        this.syntaxKind = input;
    }

    public abstract void print();

    public void addChild(Node child) {
        this.children.add(0,child);
    }

    public ArrayList<Node> getChildren() {
        return this.children;
    }

    public SyntaxKind getSyntaxKind() {
        return syntaxKind;
    }

    public void printChildren() {
        for (Node child:children) {
             child.print();
        }
    }

    public void printSyntaxKind() {
        System.out.println(String.format("<%s>",this.getSyntaxKind()));
    }

    public void printTokenAndWord(Token tokenType,String word) {
        System.out.println(tokenType+" "+word);
    }
}
