package Node;

public class LAndExpNode extends Node{
    public LAndExpNode(SyntaxKind input) {
        super(input);
    }

    @Override
    public void print() {
        printChildren();
        printSyntaxKind();
    }
}
