package Node;

public class CompUnitNode extends Node{

    public CompUnitNode(SyntaxKind input) {
        super(input);
    }

    @Override
    public void print() {
        printChildren();
        printSyntaxKind();
    }
}
