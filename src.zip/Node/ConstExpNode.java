package Node;

public class ConstExpNode extends Node{
    public ConstExpNode(SyntaxKind input) {
        super(input);
    }

    @Override
    public void print() {
        printChildren();
        printSyntaxKind();
    }
}
