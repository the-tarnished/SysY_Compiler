package lexer;

public class Word {
    private String text;
    private int line;

    public Word(String text, int line) {
        this.text = text;
        this.line = line;
    }

    public String getText() {
        return text;
    }

    public int getLine() {
        return line;
    }
}
